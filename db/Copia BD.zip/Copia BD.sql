-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.21-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para vrpex
CREATE DATABASE IF NOT EXISTS `vrpex` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `vrpex`;

-- Copiando estrutura para tabela vrpex.nation_concessionaria
CREATE TABLE IF NOT EXISTS `nation_concessionaria` (
  `vehicle` text NOT NULL,
  `estoque` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`vehicle`(765))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela vrpex.nation_concessionaria: ~490 rows (aproximadamente)
/*!40000 ALTER TABLE `nation_concessionaria` DISABLE KEYS */;
INSERT INTO `nation_concessionaria` (`vehicle`, `estoque`) VALUES
	('150', 10),
	('18performante', 10),
	('18Velar', 10),
	('19ftype', 10),
	('2020ss', 10),
	('370z', 10),
	('450crf', 10),
	('488', 10),
	('911turbos', 10),
	('acs8', 10),
	('adder', 10),
	('akuma', 10),
	('alpha', 10),
	('amarok', 10),
	('amggtr', 10),
	('amggtr2', 10),
	('aperta', 8),
	('asea', 10),
	('asterope', 10),
	('astra', 10),
	('audirs6', 10),
	('audirs7', 10),
	('autarch', 10),
	('avarus', 10),
	('aventador', 10),
	('b63s', 10),
	('bagger', 10),
	('baller', 10),
	('baller2', 10),
	('baller250', 10),
	('baller3', 10),
	('baller4', 10),
	('baller5', 10),
	('baller6', 10),
	('banshee', 10),
	('banshee2', 10),
	('bati', 10),
	('bati2', 10),
	('bestiagts', 10),
	('bf400', 10),
	('bfinjection', 10),
	('bifta', 10),
	('bison', 10),
	('bison2', 10),
	('biz25', 10),
	('bjxl', 10),
	('blade', 10),
	('blazer', 10),
	('blazer4', 10),
	('blista', 10),
	('blista2', 10),
	('blista3', 10),
	('bmci', 10),
	('bmwm3f80', 10),
	('bmwm4gts', 10),
	('bmwm8', 10),
	('bmws', 10),
	('bobcatxl', 10),
	('bodhi2', 10),
	('brasilia', 10),
	('brawler', 10),
	('brioso', 10),
	('bros60', 10),
	('btype2', 10),
	('btype3', 10),
	('buccaneer', 10),
	('buccaneer2', 10),
	('buffalo', 10),
	('buffalo2', 10),
	('buffalo3', 10),
	('bugatti', 10),
	('bugatticentodieci', 10),
	('bullet', 10),
	('burrito', 10),
	('burrito2', 10),
	('burrito4', 10),
	('carbonizzare', 10),
	('carbonrs', 10),
	('casco', 10),
	('cavalcade', 10),
	('cavalcade2', 10),
	('cb500x', 10),
	('CBTWISTER', 10),
	('cczl', 10),
	('celta', 10),
	('cesc21', 10),
	('cheburek', 10),
	('cheetah', 10),
	('cheetah2', 10),
	('chevette', 10),
	('chimera', 10),
	('chino', 10),
	('chiron17', 10),
	('civic', 10),
	('civic2010', 10),
	('civic2016', 10),
	('cliffhanger', 10),
	('clio', 10),
	('clique', 10),
	('cog552', 10),
	('cogcabrio', 10),
	('cognoscenti', 10),
	('cognoscenti2', 10),
	('comet2', 10),
	('comet3', 10),
	('comet5', 10),
	('coquette', 10),
	('coquette2', 10),
	('coquette3', 10),
	('corsa98', 10),
	('corvette', 10),
	('cronos', 10),
	('cruze', 10),
	('cyclone', 10),
	('daemon2', 10),
	('defiler', 10),
	('deveste', 10),
	('deviant', 10),
	('diablous', 10),
	('diablous2', 10),
	('dilettante', 10),
	('dloader', 10),
	('dm1200', 10),
	('dodgechargersrt', 10),
	('dominator', 10),
	('dominator2', 10),
	('dominator3', 10),
	('double', 10),
	('ds4', 10),
	('dubsta', 10),
	('dubsta2', 10),
	('dubsta3', 10),
	('dukes', 10),
	('eb110', 10),
	('elegy', 10),
	('elegy2', 10),
	('eletran17', 10),
	('ellie', 10),
	('emperor', 10),
	('emperor2', 10),
	('enduro', 10),
	('entity2', 10),
	('entityxf', 10),
	('escort', 10),
	('esskey', 10),
	('evo10', 10),
	('evoq', 10),
	('evoque', 10),
	('exemplar', 10),
	('f150', 10),
	('f458', 10),
	('f620', 10),
	('f80', 10),
	('faction', 10),
	('faction3', 10),
	('fagaloa', 10),
	('faggio', 10),
	('faggio2', 10),
	('faggio3', 10),
	('fcr', 10),
	('felon', 10),
	('feltzer2', 10),
	('feltzer3', 10),
	('ferporto', 10),
	('ferrariitalia', 10),
	('fiat', 10),
	('fiatstilo', 10),
	('fiatuno', 10),
	('fiesta', 10),
	('filthynsx', 10),
	('flashgt', 10),
	('fmgt', 10),
	('fmj', 10),
	('fordka', 10),
	('fordmustang', 10),
	('fordmustanggt', 10),
	('foxshelby', 10),
	('fpacehm', 10),
	('fq2', 10),
	('freecrawler', 10),
	('ftoro', 9),
	('fugitive', 10),
	('furoregt', 10),
	('fusca', 10),
	('fusilade', 10),
	('fusion', 10),
	('futo', 10),
	('g500', 10),
	('g65amg', 10),
	('gargoyle', 10),
	('gauntlet', 10),
	('gauntlet2', 10),
	('gb200', 10),
	('gcr2', 10),
	('glendale', 10),
	('golg7', 10),
	('gp1', 10),
	('granger', 10),
	('gresley', 10),
	('gt500', 10),
	('gtr', 10),
	('guardian', 10),
	('habanero', 10),
	('hakuchou', 10),
	('hakuchou2', 10),
	('hauler', 10),
	('hauler2', 10),
	('hayabusa', 10),
	('hcbr17', 10),
	('hermes', 10),
	('hexer', 10),
	('hilux2016', 10),
	('Hilux2019', 10),
	('hondacivictr', 10),
	('hornet', 10),
	('hotknife', 10),
	('hotring', 10),
	('huntley', 10),
	('i8', 10),
	('impaler', 10),
	('infernus', 10),
	('infernus2', 10),
	('ingot', 10),
	('innovation', 10),
	('intruder', 10),
	('issi2', 10),
	('issi3', 10),
	('italia458', 10),
	('italigtb', 10),
	('italigtb2', 10),
	('italigto', 10),
	('jackal', 10),
	('jagpr8', 10),
	('jb700', 10),
	('jellybigpeen', 10),
	('jester', 10),
	('jester3', 10),
	('jetta', 9),
	('jetta2017', 10),
	('kamacho', 10),
	('khamelion', 10),
	('kuruma', 10),
	('l200civil', 10),
	('laferrari17', 10),
	('lamborghinihuracan', 10),
	('lancerevolutionx', 10),
	('landstalker', 10),
	('lanex400', 10),
	('le7b', 10),
	('lectro', 10),
	('lp700', 10),
	('lp700r', 10),
	('lurcher', 10),
	('lx2018', 10),
	('lynx', 10),
	('m4f82', 10),
	('m6e63', 10),
	('m6gc', 10),
	('macan', 10),
	('mamba', 10),
	('manana', 10),
	('manchez', 10),
	('massacro', 10),
	('massacro2', 10),
	('mazdarx7', 10),
	('mclarenp1', 10),
	('mercedesa45', 10),
	('mercedesamgc63', 10),
	('mers63c', 10),
	('mesa', 10),
	('mesa3', 10),
	('michelli', 10),
	('minivan', 10),
	('minivan2', 10),
	('mk1rabbit', 10),
	('monroe', 10),
	('monza', 10),
	('moonbeam', 10),
	('moonbeam2', 10),
	('mule4', 10),
	('nemesis', 10),
	('neon', 10),
	('nero', 10),
	('nero2', 10),
	('nh2r', 10),
	('nightblade', 10),
	('nightshade', 10),
	('ninef', 10),
	('ninef2', 10),
	('nissan370z', 10),
	('nissangtr', 10),
	('nissangtrnismo', 10),
	('nissanskyliner34', 10),
	('nissantitan17', 10),
	('omega', 10),
	('omnis', 10),
	('oracle', 10),
	('oracle2', 10),
	('osiris', 10),
	('p1', 10),
	('p1gtr', 10),
	('p207', 10),
	('p7', 10),
	('p90d', 10),
	('paganihuayra', 10),
	('palio', 10),
	('palio97', 9),
	('panamera17turbo', 10),
	('panto', 10),
	('paradise', 10),
	('parati2007', 10),
	('pariah', 10),
	('passat', 10),
	('patriot', 10),
	('patriot2', 10),
	('pcj', 10),
	('penetrator', 10),
	('penumbra', 10),
	('peugeot207', 10),
	('peyote', 10),
	('pfister811', 10),
	('phantom', 10),
	('phoenix', 10),
	('picador', 10),
	('pigalle', 10),
	('pista', 10),
	('pista2', 10),
	('polo', 10),
	('pony', 10),
	('pony2', 10),
	('prairie', 10),
	('premier', 10),
	('primo', 10),
	('prototipo', 10),
	('punto', 10),
	('r1250', 10),
	('r6', 10),
	('r820', 10),
	('rabike', 10),
	('radi', 10),
	('raiden', 10),
	('raiden2', 10),
	('rallytruck', 10),
	('rancherxl', 10),
	('rapidgt', 10),
	('rapidgt2', 10),
	('rapidgt3', 10),
	('raptor', 10),
	('RAPTOR150', 10),
	('rc', 10),
	('reaper', 10),
	('rebel2', 10),
	('retinue', 10),
	('rhapsody', 10),
	('riata', 10),
	('rmodgt63', 10),
	('rmodlp750', 10),
	('rmodveneno', 10),
	('rocoto', 10),
	('rsvr16', 10),
	('ruffian', 10),
	('ruiner', 10),
	('rumpo', 10),
	('rumpo2', 10),
	('rumpo3', 10),
	('ruston', 10),
	('rx7veilside', 10),
	('rxf7', 10),
	('s10', 10),
	('sabregt', 10),
	('sabregt2', 10),
	('sadler', 10),
	('sanchez', 10),
	('sanchez2', 10),
	('sandking', 10),
	('sandking2', 10),
	('santafe', 10),
	('saveiro', 10),
	('sc1', 10),
	('schafter3', 10),
	('schafter4', 10),
	('schafter5', 10),
	('schlagen', 10),
	('schwarzer', 10),
	('seminole', 10),
	('sentinel', 10),
	('sentinel3', 8),
	('serrano', 10),
	('seven70', 10),
	('sheava', 10),
	('shotaro', 10),
	('skyline', 10),
	('slamvan', 10),
	('slamvan3', 10),
	('sonata18', 10),
	('sovereign', 10),
	('specter', 10),
	('specter2', 10),
	('stalion', 10),
	('stalion2', 10),
	('stanier', 10),
	('stinger', 10),
	('stingergt', 10),
	('stockade', 10),
	('stratum', 10),
	('streiter', 10),
	('stretch', 10),
	('sultan', 10),
	('sultanrs', 10),
	('surano', 10),
	('surfboard', 10),
	('surfer', 10),
	('surge', 10),
	('swinger', 10),
	('t20', 10),
	('tailgater', 10),
	('taipam', 10),
	('tampa', 10),
	('tampa2', 10),
	('tempesta', 10),
	('teslapd', 10),
	('teslaprior', 10),
	('tezeract', 10),
	('thrust', 10),
	('tiger', 10),
	('torero', 10),
	('tornado', 10),
	('tornado2', 10),
	('tornado6', 10),
	('toros', 10),
	('toyotasupra', 10),
	('trailcat', 10),
	('tritonhpe', 10),
	('trophytruck', 10),
	('trophytruck2', 10),
	('tropos', 10),
	('tulip', 10),
	('turismo2', 10),
	('turismor', 10),
	('tyrant', 10),
	('tyrus', 10),
	('uno', 10),
	('upzinho', 10),
	('urus', 10),
	('vacca', 10),
	('vader', 10),
	('vagner', 10),
	('vamos', 10),
	('velociraptor', 10),
	('veloster', 10),
	('verlierer2', 10),
	('versa', 10),
	('vigero', 10),
	('vindicator', 10),
	('virgo', 10),
	('virgo2', 10),
	('virgo3', 10),
	('visione', 10),
	('voltic', 10),
	('voodoo', 10),
	('voodoo2', 10),
	('vortex', 10),
	('voyage', 10),
	('vwgolf', 10),
	('warrener', 10),
	('washington', 10),
	('windsor', 10),
	('windsor2', 10),
	('wolfsbane', 10),
	('x6m', 10),
	('xa21', 10),
	('xj', 10),
	('xls', 10),
	('xls2', 10),
	('xr3', 10),
	('xre2019', 10),
	('xt66', 10),
	('yosemite', 10),
	('youga', 10),
	('z1000', 10),
	('z190', 10),
	('z4alchemist', 10),
	('z4bmw', 10),
	('zentorno', 10),
	('zion', 10),
	('zion2', 10),
	('zombiea', 10),
	('zombieb', 10),
	('ztype', 10),
	('zx10', 10);
/*!40000 ALTER TABLE `nation_concessionaria` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_calls
CREATE TABLE IF NOT EXISTS `ps_phone_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_calls: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_calls` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_calls` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_contacts
CREATE TABLE IF NOT EXISTS `ps_phone_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `number` varchar(50) NOT NULL,
  `display` varchar(50) NOT NULL,
  `bank` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_contacts: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_contacts` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_darkweb_account
CREATE TABLE IF NOT EXISTS `ps_phone_darkweb_account` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_darkweb_account: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_darkweb_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_darkweb_account` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_darkweb_layers
CREATE TABLE IF NOT EXISTS `ps_phone_darkweb_layers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_darkweb_layers: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_darkweb_layers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_darkweb_layers` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_darkweb_layers_messages
CREATE TABLE IF NOT EXISTS `ps_phone_darkweb_layers_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_layer` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_layers_messages` (`id_layer`) USING BTREE,
  CONSTRAINT `FK_layers_messages` FOREIGN KEY (`id_layer`) REFERENCES `ps_phone_darkweb_layers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_darkweb_layers_messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_darkweb_layers_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_darkweb_layers_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_darkweb_layers_users
CREATE TABLE IF NOT EXISTS `ps_phone_darkweb_layers_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number_layer` varchar(50) NOT NULL,
  `admin` tinyint(4) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_darkweb_layers_users: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_darkweb_layers_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_darkweb_layers_users` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_account
CREATE TABLE IF NOT EXISTS `ps_phone_insta_account` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `verify` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_account: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_account` DISABLE KEYS */;
INSERT INTO `ps_phone_insta_account` (`id`, `name`, `username`, `password`, `avatar`, `description`, `verify`) VALUES
	(2, 'zaum123', 'zaum123', '123456', 'default.png', NULL, 0);
/*!40000 ALTER TABLE `ps_phone_insta_account` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_chats
CREATE TABLE IF NOT EXISTS `ps_phone_insta_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `username_from` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_chats: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_chats` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_comments
CREATE TABLE IF NOT EXISTS `ps_phone_insta_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_comments: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_comments` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_followers
CREATE TABLE IF NOT EXISTS `ps_phone_insta_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `followed` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_followers: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_followers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_followers` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_likes
CREATE TABLE IF NOT EXISTS `ps_phone_insta_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_likes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_likes` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_messages
CREATE TABLE IF NOT EXISTS `ps_phone_insta_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_chat` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_insta_messages` (`id_chat`) USING BTREE,
  CONSTRAINT `FK_insta_messages` FOREIGN KEY (`id_chat`) REFERENCES `ps_phone_insta_chats` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_posts
CREATE TABLE IF NOT EXISTS `ps_phone_insta_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `filter` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_posts: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_insta_posts` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_insta_stories
CREATE TABLE IF NOT EXISTS `ps_phone_insta_stories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `filter` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_insta_stories: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_insta_stories` DISABLE KEYS */;
INSERT INTO `ps_phone_insta_stories` (`id`, `username`, `image`, `description`, `location`, `filter`, `created`) VALUES
	(1, 'zaum123', 'https://media.discordapp.net/attachments/826819916463210558/887919675986559036/screenshot.jpg', NULL, NULL, NULL, '2021-09-16 01:01:47'),
	(2, 'zaum123', 'https://media.discordapp.net/attachments/826819916463210558/888148666634862722/screenshot.jpg', NULL, NULL, NULL, '2021-09-16 16:04:43');
/*!40000 ALTER TABLE `ps_phone_insta_stories` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_messages
CREATE TABLE IF NOT EXISTS `ps_phone_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_messages: 0 rows
/*!40000 ALTER TABLE `ps_phone_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_settings
CREATE TABLE IF NOT EXISTS `ps_phone_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `option` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_settings: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_settings` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_tinder_account
CREATE TABLE IF NOT EXISTS `ps_phone_tinder_account` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `interested` varchar(50) NOT NULL,
  `avatar` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `passions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_tinder_account: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_tinder_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_tinder_account` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_tinder_chats
CREATE TABLE IF NOT EXISTS `ps_phone_tinder_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_from` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_tinder_chats: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_tinder_chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_tinder_chats` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_tinder_likes
CREATE TABLE IF NOT EXISTS `ps_phone_tinder_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_liked` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_tinder_likes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_tinder_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_tinder_likes` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_tinder_messages
CREATE TABLE IF NOT EXISTS `ps_phone_tinder_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_chat` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_tinder_messages` (`id_chat`) USING BTREE,
  CONSTRAINT `FK_tinder_messages` FOREIGN KEY (`id_chat`) REFERENCES `ps_phone_tinder_chats` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_tinder_messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_tinder_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_tinder_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_twiiter_account
CREATE TABLE IF NOT EXISTS `ps_phone_twiiter_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_twiiter_account: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_twiiter_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_twiiter_account` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_twiiter_hashtags
CREATE TABLE IF NOT EXISTS `ps_phone_twiiter_hashtags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_twiiter_hashtags: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_twiiter_hashtags` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_twiiter_hashtags` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_twiiter_mentions
CREATE TABLE IF NOT EXISTS `ps_phone_twiiter_mentions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tweet` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `mentioned` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_twiiter_mentions: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_twiiter_mentions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_twiiter_mentions` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_twiiter_tweets
CREATE TABLE IF NOT EXISTS `ps_phone_twiiter_tweets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `hashtags` text DEFAULT NULL,
  `mentions` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_twiiter_tweets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_twiiter_tweets` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_twiiter_tweets` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_account
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_account` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_account: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_account` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_calls
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_calls: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_calls` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_calls` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_chats
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_chats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_chats: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_chats` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_groups
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_groups: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_groups_messages
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_groups_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_groups_messages` (`id_group`) USING BTREE,
  CONSTRAINT `FK_groups_messages` FOREIGN KEY (`id_group`) REFERENCES `ps_phone_whatsapp_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_groups_messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_groups_users
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number_group` varchar(50) NOT NULL,
  `admin` tinyint(4) NOT NULL DEFAULT 0,
  `phone` varchar(50) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_groups_users: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_groups_users` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_messages
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_chat` int(11) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_messages` (`id_chat`) USING BTREE,
  CONSTRAINT `FK_messages` FOREIGN KEY (`id_chat`) REFERENCES `ps_phone_whatsapp_chats` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_messages` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.ps_phone_whatsapp_stories
CREATE TABLE IF NOT EXISTS `ps_phone_whatsapp_stories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `filter` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela vrpex.ps_phone_whatsapp_stories: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ps_phone_whatsapp_stories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps_phone_whatsapp_stories` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_banco
CREATE TABLE IF NOT EXISTS `vrp_banco` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `extrato` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Copiando dados para a tabela vrpex.vrp_banco: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_banco` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_banco` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_business
CREATE TABLE IF NOT EXISTS `vrp_business` (
  `user_id` int(11) NOT NULL,
  `capital` int(11) DEFAULT NULL,
  `laundered` int(11) DEFAULT NULL,
  `reset_timestamp` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_business_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_business: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_business` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_business` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_ebay
CREATE TABLE IF NOT EXISTS `vrp_ebay` (
  `id` int(9) unsigned NOT NULL,
  `user_id` int(6) NOT NULL,
  `item_id` varchar(255) NOT NULL DEFAULT '0',
  `quantidade` int(9) NOT NULL DEFAULT 0,
  `price` int(9) NOT NULL DEFAULT 0,
  `anony` varchar(5) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_ebay: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_ebay` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_ebay` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_estoque
CREATE TABLE IF NOT EXISTS `vrp_estoque` (
  `vehicle` varchar(100) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_estoque: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_estoque` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_estoque` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_helpdesk_respostas
CREATE TABLE IF NOT EXISTS `vrp_helpdesk_respostas` (
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `case_id` int(11) NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_helpdesk_respostas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_helpdesk_respostas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_helpdesk_respostas` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_helpdesk_ticket
CREATE TABLE IF NOT EXISTS `vrp_helpdesk_ticket` (
  `user_id` tinyint(11) NOT NULL,
  `title` text NOT NULL DEFAULT '',
  `message` text NOT NULL DEFAULT '',
  `createdAt` text NOT NULL DEFAULT '',
  `status` text NOT NULL DEFAULT '',
  `id` tinyint(4) NOT NULL,
  `case_id` tinyint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_helpdesk_ticket: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_helpdesk_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_helpdesk_ticket` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_homes_permissions
CREATE TABLE IF NOT EXISTS `vrp_homes_permissions` (
  `owner` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `garage` int(11) NOT NULL,
  `home` varchar(100) NOT NULL DEFAULT '',
  `tax` varchar(24) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_homes_permissions: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_homes_permissions` DISABLE KEYS */;
INSERT INTO `vrp_homes_permissions` (`owner`, `user_id`, `garage`, `home`, `tax`) VALUES
	(1, 1, 1, 'LX50', '1631668022'),
	(1, 2, 1, 'MS04', '1631669606'),
	(1, 1, 1, 'FH82', '1631671192'),
	(1, 1, 1, 'MS05', '1631671673');
/*!40000 ALTER TABLE `vrp_homes_permissions` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_priority
CREATE TABLE IF NOT EXISTS `vrp_priority` (
  `id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_priority: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_priority` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_priority` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_srv_data
CREATE TABLE IF NOT EXISTS `vrp_srv_data` (
  `dkey` varchar(100) NOT NULL,
  `dvalue` text DEFAULT NULL,
  PRIMARY KEY (`dkey`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_srv_data: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_srv_data` DISABLE KEYS */;
INSERT INTO `vrp_srv_data` (`dkey`, `dvalue`) VALUES
	('chest:mafia', '{"dinheirosujo":{"amount":134000}}'),
	('chest:u12veh_asea', '{}'),
	('custom:u15veh_t20', '{"model":"t20","smokecolor":[253,237,237],"extracolor":[3,0],"pcolortype":"metálico","color":[7,7],"scolortype":"metálico","xenoncolor":-1,"customPcolor":[50,59,71],"wheeltype":7,"bulletProofTyres":1,"damage":0.17697448730468,"mods":{"1":{"mod":1},"2":{"mod":1},"3":{"mod":0},"4":{"mod":1},"5":{"mod":-1},"6":{"mod":-1},"7":{"mod":0},"8":{"mod":-1},"9":{"mod":-1},"10":{"mod":-1},"11":{"mod":3},"12":{"mod":2},"13":{"mod":-1},"14":{"mod":-1},"15":{"mod":-1},"16":{"mod":-1},"17":{"mod":-1},"18":{"mod":1},"19":{"mod":-1},"20":{"mod":-1},"21":{"mod":-1},"22":{"mod":0},"23":{"variation":false,"mod":4},"24":{"variation":false,"mod":-1},"25":{"mod":-1},"26":{"mod":-1},"27":{"mod":-1},"28":{"mod":-1},"29":{"mod":-1},"30":{"mod":-1},"31":{"mod":-1},"32":{"mod":-1},"33":{"mod":-1},"34":{"mod":-1},"35":{"mod":-1},"36":{"mod":-1},"37":{"mod":-1},"38":{"mod":-1},"39":{"mod":-1},"40":{"mod":-1},"41":{"mod":-1},"42":{"mod":-1},"43":{"mod":-1},"44":{"mod":-1},"45":{"mod":-1},"46":{"mod":-1},"47":{"mod":-1},"48":{"mod":-1},"0":{"mod":-1}},"windowtint":1,"customScolor":[50,59,71],"plateindex":1,"neon":true,"neoncolor":[255,0,255],"vehicle":4329730}'),
	('custom:u2veh_aperta', '{"bulletProofTyres":1,"windowtint":false,"plateindex":0,"neon":false,"smokecolor":[255,255,255],"scolortype":"metálico","xenoncolor":-1,"damage":0.0,"pcolortype":"metálico","wheeltype":0,"color":[1,0],"customPcolor":[0,0,0],"mods":{"1":{"mod":-1},"2":{"mod":-1},"3":{"mod":-1},"4":{"mod":-1},"5":{"mod":-1},"6":{"mod":-1},"7":{"mod":-1},"8":{"mod":-1},"9":{"mod":-1},"10":{"mod":-1},"11":{"mod":-1},"12":{"mod":-1},"13":{"mod":-1},"14":{"mod":-1},"15":{"mod":-1},"16":{"mod":-1},"17":{"mod":-1},"18":{"mod":0},"19":{"mod":-1},"20":{"mod":-1},"21":{"mod":-1},"22":{"mod":0},"23":{"mod":-1,"variation":false},"24":{"mod":-1,"variation":false},"25":{"mod":-1},"26":{"mod":-1},"27":{"mod":-1},"28":{"mod":-1},"29":{"mod":-1},"30":{"mod":-1},"31":{"mod":-1},"32":{"mod":-1},"33":{"mod":-1},"34":{"mod":-1},"35":{"mod":-1},"36":{"mod":-1},"37":{"mod":-1},"38":{"mod":-1},"39":{"mod":-1},"40":{"mod":-1},"41":{"mod":-1},"42":{"mod":-1},"43":{"mod":-1},"44":{"mod":-1},"45":{"mod":-1},"46":{"mod":-1},"47":{"mod":-1},"48":{"mod":-1},"0":{"mod":-1}},"customScolor":[8,8,8],"extracolor":[4,156],"neoncolor":[255,0,255],"model":"laferrari a","vehicle":1751810}'),
	('custom:u2veh_rmodx6', '{"plateindex":0,"scolortype":"metálico","bulletProofTyres":1,"customScolor":[0,85,196],"extracolor":[62,156],"xenoncolor":-1,"mods":{"1":{"mod":0},"2":{"mod":-1},"3":{"mod":1},"4":{"mod":-1},"5":{"mod":0},"6":{"mod":-1},"7":{"mod":-1},"8":{"mod":-1},"9":{"mod":-1},"10":{"mod":-1},"11":{"mod":-1},"12":{"mod":-1},"13":{"mod":2},"14":{"mod":-1},"15":{"mod":3},"16":{"mod":-1},"17":{"mod":-1},"18":{"mod":1},"19":{"mod":-1},"20":{"mod":-1},"21":{"mod":-1},"22":{"mod":0},"23":{"mod":-1,"variation":false},"24":{"mod":-1,"variation":false},"25":{"mod":-1},"26":{"mod":-1},"27":{"mod":-1},"28":{"mod":-1},"29":{"mod":-1},"30":{"mod":-1},"31":{"mod":-1},"32":{"mod":-1},"33":{"mod":-1},"34":{"mod":-1},"35":{"mod":-1},"36":{"mod":-1},"37":{"mod":-1},"38":{"mod":-1},"39":{"mod":-1},"40":{"mod":-1},"41":{"mod":-1},"42":{"mod":-1},"43":{"mod":-1},"44":{"mod":-1},"45":{"mod":-1},"46":{"mod":-1},"47":{"mod":-1},"48":{"mod":-1},"0":{"mod":4}},"neon":false,"color":[62,70],"neoncolor":[255,0,255],"customPcolor":[0,16,41],"smokecolor":[255,255,255],"windowtint":false,"wheeltype":3,"vehicle":680194,"pcolortype":"metálico","model":"rmodx6","damage":0.0}'),
	('custom:u3veh_aperta', '{"windowtint":false,"scolortype":"metálico","customPcolor":[0,0,0],"customScolor":[8,8,8],"neoncolor":[255,0,255],"vehicle":2726914,"mods":{"1":{"mod":-1},"2":{"mod":-1},"3":{"mod":-1},"4":{"mod":-1},"5":{"mod":-1},"6":{"mod":-1},"7":{"mod":-1},"8":{"mod":-1},"9":{"mod":-1},"10":{"mod":-1},"11":{"mod":-1},"12":{"mod":-1},"13":{"mod":-1},"14":{"mod":-1},"15":{"mod":-1},"16":{"mod":-1},"17":{"mod":-1},"18":{"mod":0},"19":{"mod":-1},"20":{"mod":-1},"21":{"mod":-1},"22":{"mod":0},"23":{"variation":false,"mod":-1},"24":{"variation":false,"mod":-1},"25":{"mod":-1},"26":{"mod":-1},"27":{"mod":-1},"28":{"mod":-1},"29":{"mod":-1},"30":{"mod":-1},"31":{"mod":-1},"32":{"mod":-1},"33":{"mod":-1},"34":{"mod":-1},"35":{"mod":-1},"36":{"mod":-1},"37":{"mod":-1},"38":{"mod":-1},"39":{"mod":-1},"40":{"mod":-1},"41":{"mod":-1},"42":{"mod":-1},"43":{"mod":-1},"44":{"mod":-1},"45":{"mod":-1},"46":{"mod":-1},"47":{"mod":-1},"48":{"mod":-1},"0":{"mod":-1}},"xenoncolor":-1,"bulletProofTyres":1,"damage":0.0,"plateindex":0,"color":[1,0],"neon":false,"pcolortype":"metálico","extracolor":[4,156],"model":"laferrari a","wheeltype":0,"smokecolor":[255,255,255]}'),
	('custom:u3veh_ftoro', '{"customPcolor":[0,0,0]}'),
	('custom:u3veh_jetta', '{"customPcolor":[0,0,0]}'),
	('custom:u3veh_palio97', '{"customPcolor":[0,0,0]}');
/*!40000 ALTER TABLE `vrp_srv_data` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_users
CREATE TABLE IF NOT EXISTS `vrp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_login` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `whitelisted` tinyint(1) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_users: ~9 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_users` DISABLE KEYS */;
INSERT INTO `vrp_users` (`id`, `last_login`, `ip`, `whitelisted`, `banned`) VALUES
	(1, '', '', 1, 0),
	(2, '', '', 1, 0),
	(3, '', '', 1, 0),
	(4, '', '', 0, 0),
	(5, '', '', 1, 0),
	(6, '', '', 0, 0),
	(7, '', '', 1, 0),
	(8, '', '', 1, 0),
	(9, '', '', 1, 0),
	(10, '', '', 0, 0),
	(11, '', '', 0, 0),
	(12, '', '', 1, 0),
	(13, '', '', 1, 0),
	(14, '', '', 0, 0),
	(15, '', '', 1, 0),
	(16, '', '', 0, 0);
/*!40000 ALTER TABLE `vrp_users` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_data
CREATE TABLE IF NOT EXISTS `vrp_user_data` (
  `user_id` int(11) NOT NULL,
  `dkey` varchar(100) NOT NULL,
  `dvalue` text DEFAULT NULL,
  PRIMARY KEY (`user_id`,`dkey`),
  CONSTRAINT `fk_user_data_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_data: ~25 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_data` DISABLE KEYS */;
INSERT INTO `vrp_user_data` (`user_id`, `dkey`, `dvalue`) VALUES
	(1, 'currentCharacterMode', '{"noseBridge":-0.07,"chestModel":-1,"eyebrowsColor":56,"makeupModel":-1,"cheekboneHeight":0,"blushColor":0,"blushModel":-1,"sundamageModel":-1,"noseLength":0,"noseShift":0,"noseHeight":-1,"eyebrowsHeight":-0.71,"eyebrowsModel":0,"cheeksWidth":0,"noseWidth":0,"firstHairColor":56,"jawWidth":0.83,"lipstickModel":-1,"beardColor":61,"skinColor":6,"noseTip":0,"jawHeight":0,"secondHairColor":28,"lipstickColor":0,"chinShape":0,"lips":-0.68,"cheekboneWidth":0,"chestColor":0,"chinLength":0.16,"neckWidth":0.99,"eyesColor":5,"ageingModel":-1,"complexionModel":-1,"hairModel":5,"blemishesModel":-1,"fathersID":0,"shapeMix":0.5,"mothersID":21,"eyebrowsWidth":0,"chinPosition":0.75,"chinWidth":0.22,"frecklesModel":-1,"beardModel":14}'),
	(1, 'ps_bank_history', '[{"name":"Transferencia #2","type":"up","value":20000}]'),
	(1, 'vRP:datatable', '{"weapons":{"WEAPON_COMBATPISTOL":{"ammo":0},"WEAPON_COMBATPDW":{"ammo":201},"WEAPON_STUNGUN":{"ammo":1},"WEAPON_CARBINERIFLE":{"ammo":249},"WEAPON_PUMPSHOTGUN_MK2":{"ammo":238},"WEAPON_PISTOL_MK2":{"ammo":233},"WEAPON_DAGGER":{"ammo":0}},"inventory":{"batata":{"amount":1},"celular":{"amount":6},"dinheirosujo":{"amount":868},"roupas":{"amount":1},"radio":{"amount":1}},"colete":0,"thirst":100,"health":291,"position":{"z":44.23579406738281,"y":3.2462990283966,"x":-544.488525390625},"cloakroom_idle":{"p10":[-1,0],"19":[33620481,2,0],"p7":[-1,0],"17":[0,2,0],"3":[15,0,1],"2":[5,0,0],"1":[0,0,2],"0":[0,0,0],"p5":[-1,0],"15":[0,1,100],"11":[344,0,1],"13":[0,2,0],"9":[0,0,2],"modelhash":1885233650,"7":[0,0,2],"p8":[-1,0],"18":[16777728,1,0],"20":[16908802,2,16],"10":[0,0,2],"14":[0,0,255],"12":[0,0,0],"p2":[-1,0],"16":[0,1,6],"p0":[-1,0],"p3":[-1,0],"4":[126,0,1],"6":[55,0,1],"p1":[-1,0],"p4":[-1,0],"p9":[-1,0],"p6":[16,0],"5":[84,0,2],"8":[15,0,2]},"customization":{"1":[0,0,2],"2":[5,0,0],"3":[15,0,1],"4":[54,0,1],"5":[84,0,2],"6":[5,0,1],"7":[0,0,2],"8":[15,0,2],"9":[0,0,2],"10":[0,0,2],"11":[15,0,2],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,1,100],"16":[0,1,1],"17":[0,2,0],"18":[16777728,1,0],"19":[33620481,2,0],"20":[33686018,2,16],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[16,0],"modelhash":1885233650,"p8":[-1,0],"p7":[3,0],"p9":[-1,0],"p5":[-1,0],"p10":[-1,0],"p0":[-1,0]},"groups":{"Concessionaria":true,"mafia":true,"Dono":true},"hunger":47.4000000000001,"gaptitudes":{"physical":{"strength":1900}}}'),
	(1, 'vRP:spawnController', '2'),
	(1, 'vRP:tattoos', '{"FM_Tat_M_037":["multiplayer_overlays"],"FM_Tat_M_018":["multiplayer_overlays"],"MP_MP_Biker_Tat_050_M":["mpbiker_overlays"],"MP_MP_Biker_Tat_044_M":["mpbiker_overlays"],"MP_Christmas2017_Tattoo_008_M":["mpchristmas2017_overlays"],"MP_LR_Tat_008_M":["mplowrider2_overlays"],"MP_MP_Stunt_tat_010_M":["mpstunt_overlays"],"MP_MP_Biker_Tat_046_M":["mpbiker_overlays"],"MP_LR_Tat_018_M":["mplowrider2_overlays"]}'),
	(2, 'currentCharacterMode', '{"sundamageModel":-1,"noseBridge":0,"shapeMix":0.5,"hairModel":2,"chestModel":-1,"noseHeight":0,"chinWidth":0,"eyebrowsColor":0,"noseLength":0,"lipstickColor":0,"blushColor":0,"firstHairColor":12,"eyebrowsHeight":0,"skinColor":6,"lips":0,"chestColor":0,"secondHairColor":0,"lipstickModel":-1,"blemishesModel":-1,"ageingModel":-1,"mothersID":21,"neckWidth":0,"cheeksWidth":0,"chinShape":0,"blushModel":-1,"cheekboneWidth":0,"makeupModel":-1,"cheekboneHeight":0,"noseShift":0,"beardColor":0,"frecklesModel":-1,"jawHeight":0,"eyebrowsWidth":0,"eyebrowsModel":0,"complexionModel":-1,"eyesColor":0,"beardModel":-1,"chinPosition":0,"noseTip":0,"fathersID":0,"jawWidth":0,"chinLength":0,"noseWidth":0}'),
	(2, 'ps_bank_history', '[{"name":"Transferencia #1","type":"down","value":20000}]'),
	(2, 'vRP:colete', '100'),
	(2, 'vRP:datatable', '{"weapons":{"WEAPON_PUMPSHOTGUN_MK2":{"ammo":39},"WEAPON_COMBATPISTOL":{"ammo":205},"WEAPON_KNIFE":{"ammo":0},"WEAPON_COMBATPDW":{"ammo":0},"WEAPON_SMG":{"ammo":221},"WEAPON_CARBINERIFLE":{"ammo":0},"WEAPON_FLASHLIGHT":{"ammo":0},"WEAPON_STUNGUN":{"ammo":-1},"WEAPON_NIGHTSTICK":{"ammo":0}},"inventory":{"celular":{"amount":2},"roupas":{"amount":1}},"colete":0,"thirst":100,"health":222,"position":{"z":82.5231704711914,"y":293.5154724121094,"x":-532.427734375},"cloakroom_idle":{"p10":[-1,0],"6":[42,0,2],"5":[84,0,2],"4":[5,0,2],"p9":[-1,0],"2":[2,0,0],"1":[0,0,2],"0":[0,0,0],"p5":[-1,0],"15":[0,2,228],"11":[22,0,2],"13":[0,2,0],"9":[0,0,2],"8":[15,0,2],"7":[0,0,2],"p8":[-1,0],"18":[33554944,2,255],"20":[33686018,2,255],"10":[0,0,2],"14":[0,0,255],"12":[0,0,0],"p2":[-1,0],"p4":[-1,0],"p0":[-1,0],"p6":[-1,0],"16":[0,2,255],"p1":[-1,0],"19":[33686018,2,255],"17":[0,2,255],"modelhash":1885233650,"p7":[-1,0],"3":[0,0,2],"p3":[-1,0]},"customization":{"1":[0,0,2],"2":[2,0,0],"3":[0,0,2],"4":[35,0,2],"5":[84,0,2],"6":[42,0,2],"7":[0,0,2],"8":[15,0,2],"9":[0,0,2],"10":[0,0,2],"11":[22,0,2],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,2,100],"16":[0,2,255],"17":[0,2,255],"18":[33554944,2,255],"19":[33686018,2,255],"20":[33686018,2,255],"p5":[-1,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"p10":[-1,0],"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"p0":[-1,0],"modelhash":1885233650,"0":[0,0,0]},"gaptitudes":{"physical":{"strength":20}},"groups":{"Concessionaria":true,"Coronel":true,"Dono":true},"hunger":100}'),
	(2, 'vRP:spawnController', '2'),
	(2, 'vRP:tattoos', '{"FM_Tat_M_037":["multiplayer_overlays"],"MP_Bea_M_Neck_000":["mpbeach_overlays"],"MP_LR_Tat_033_M":["mplowrider_overlays"],"MP_MP_Stunt_tat_047_M":["mpstunt_overlays"],"MP_MP_Biker_Tat_050_M":["mpbiker_overlays"],"MP_LR_Tat_003_M":["mplowrider2_overlays"],"FM_Tat_M_033":["multiplayer_overlays"],"MP_Buis_M_Neck_000":["mpbusiness_overlays"]}'),
	(3, 'currentCharacterMode', '{"noseBridge":0,"chestModel":-1,"eyebrowsColor":0,"makeupModel":-1,"cheekboneHeight":0,"blushColor":0,"blushModel":-1,"sundamageModel":-1,"noseLength":0,"noseShift":0,"chestColor":0,"eyebrowsHeight":0,"eyebrowsModel":0,"cheeksWidth":0,"noseWidth":0,"firstHairColor":0,"jawWidth":0,"lipstickModel":-1,"cheekboneWidth":0,"beardColor":0,"jawHeight":0,"beardModel":-1,"noseHeight":0,"complexionModel":-1,"fathersID":0,"lips":0,"mothersID":21,"lipstickColor":0,"chinLength":0,"shapeMix":0.5,"eyesColor":0,"ageingModel":-1,"frecklesModel":-1,"hairModel":4,"blemishesModel":-1,"secondHairColor":0,"chinWidth":0.66,"neckWidth":-0.72,"eyebrowsWidth":0,"chinPosition":0,"chinShape":-0.8,"skinColor":9,"noseTip":0}'),
	(3, 'vRP:colete', '100'),
	(3, 'vRP:datatable', '{"weapons":{"WEAPON_MUSKET":{"ammo":197},"WEAPON_COMBATPISTOL":{"ammo":100},"WEAPON_COMBATPDW":{"ammo":146},"WEAPON_PUMPSHOTGUN_MK2":{"ammo":0},"WEAPON_CARBINERIFLE":{"ammo":189},"WEAPON_STUNGUN":{"ammo":1},"WEAPON_NIGHTSTICK":{"ammo":0},"WEAPON_FIREEXTINGUISHER":{"ammo":0}},"inventory":{"wammo|WEAPON_MUSKET":{"amount":210},"ferro2":{"amount":2},"dinheirosujo":{"amount":1202349},"diamante2":{"amount":2},"ouro2":{"amount":2},"wammo|WEAPON_CARBINERIFLE":{"amount":168},"wbody|WEAPON_FLASHLIGHT":{"amount":1}},"colete":0,"thirst":100,"health":267,"position":{"z":26.1005630493164,"y":-986.1802978515625,"x":832.4202270507813},"cloakroom_idle":{"1":[20,0,1],"2":[4,0,0],"3":[5,0,1],"4":[118,0,1],"5":[20,0,1],"6":[77,0,1],"7":[0,0,2],"8":[0,1,1],"9":[0,0,1],"10":[0,0,1],"11":[20,0,1],"12":[65536,0,0],"13":[0,1,0],"14":[0,0,255],"15":[0,1,228],"16":[0,1,255],"17":[1,1,255],"18":[16777472,1,255],"19":[33620225,2,255],"20":[16843009,1,255],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"p10":[-1,0],"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"modelhash":1885233650,"p5":[-1,0],"p0":[-1,0]},"gaptitudes":{"physical":{"strength":670}},"hunger":100,"customization":{"1":[20,0,1],"2":[4,0,0],"3":[15,0,1],"4":[118,0,1],"5":[20,0,1],"6":[77,0,1],"7":[0,0,2],"8":[23,0,1],"9":[14,0,1],"10":[-1,0,2],"11":[20,0,1],"12":[65536,0,0],"13":[0,1,0],"14":[0,0,255],"15":[0,1,100],"16":[0,1,255],"17":[0,1,255],"18":[16777472,1,255],"19":[33620225,2,255],"20":[16908545,1,255],"p5":[-1,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"p0":[-1,0],"p8":[-1,0],"p7":[3,0],"p9":[-1,0],"modelhash":1885233650,"p10":[-1,0],"0":[0,0,0]},"groups":{"Admin":true,"PaisanaMecanico":true,"Concessionaria":true}}'),
	(3, 'vRP:spawnController', '2'),
	(5, 'currentCharacterMode', '{"makeupModel":-1,"firstHairColor":1,"noseLength":0,"lips":0,"chinLength":0,"cheeksWidth":0,"beardModel":11,"shapeMix":0.5,"noseShift":0,"jawHeight":0,"frecklesModel":-1,"eyebrowsModel":1,"chinWidth":0,"noseWidth":0,"blushColor":0,"noseBridge":0,"mothersID":21,"hairModel":73,"lipstickColor":0,"blushModel":-1,"cheekboneHeight":0,"fathersID":4,"gender":0,"chinPosition":0,"eyebrowsWidth":0,"chestColor":0,"chinShape":0,"eyebrowsColor":3,"sundamageModel":-1,"complexionModel":-1,"skinColor":6,"noseHeight":0,"eyesColor":0,"chestModel":-1,"blemishesModel":-1,"noseTip":0,"beardColor":1,"cheekboneWidth":0,"ageingModel":4,"neckWidth":0,"lipstickModel":-1,"eyebrowsHeight":0,"secondHairColor":1,"jawWidth":0}'),
	(5, 'vRP:colete', '100'),
	(5, 'vRP:datatable', '{"cloakroom_idle":{"9":[0,0,2],"8":[15,0,2],"7":[41,0,2],"6":[42,0,2],"5":[84,0,2],"4":[5,0,2],"3":[0,0,2],"p7":[-1,0],"17":[0,2,0],"p9":[-1,0],"19":[33686018,2,0],"15":[0,2,100],"p3":[-1,0],"13":[0,2,0],"p5":[-1,0],"p1":[15,0],"11":[22,0,2],"2":[4,0,0],"modelhash":1885233650,"0":[0,0,0],"18":[33554944,2,0],"20":[33686018,2,15],"p4":[-1,0],"16":[0,2,1],"p6":[-1,0],"14":[0,0,255],"p10":[-1,0],"12":[0,0,0],"p2":[-1,0],"10":[0,0,2],"p0":[-1,0],"p8":[-1,0],"1":[0,0,2]},"hunger":17.87499999999998,"colete":0,"inventory":{"dinheirosujo":{"amount":941}},"thirst":32.29999999999996,"customization":{"1":[0,0,2],"2":[73,0,0],"3":[19,0,1],"4":[87,1,2],"5":[0,0,1],"6":[25,0,2],"7":[0,0,1],"8":[15,0,2],"9":[14,0,1],"10":[-1,0,2],"11":[271,1,2],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,1,100],"16":[1,2,2],"17":[16777216,1,0],"18":[16777728,2,0],"19":[16908546,1,0],"20":[33685762,2,0],"0":[0,0,0],"p1":[-1,0],"p2":[0,0],"p8":[-1,0],"p0":[16,1],"p7":[-1,0],"modelhash":1885233650,"p9":[-1,0],"p10":[-1,0],"p4":[-1,0],"p3":[-1,0],"p6":[-1,0],"p5":[-1,0]},"position":{"z":32.33759307861328,"y":3079.156005859375,"x":-1919.129638671875},"groups":{"PaisanaSoldado":true,"Concessionaria":true,"Dono":true},"gaptitudes":{"physical":{"strength":20}},"health":160,"weapons":{"WEAPON_NIGHTSTICK":{"ammo":0},"WEAPON_KNIFE":{"ammo":0},"WEAPON_FIREEXTINGUISHER":{"ammo":2000},"WEAPON_COMBATPISTOL":{"ammo":116},"WEAPON_FLASHLIGHT":{"ammo":0},"WEAPON_SMG":{"ammo":0},"WEAPON_PUMPSHOTGUN_MK2":{"ammo":22},"WEAPON_STUNGUN":{"ammo":-1},"WEAPON_CARBINERIFLE":{"ammo":53},"WEAPON_COMBATPDW":{"ammo":0}}}'),
	(5, 'vRP:spawnController', '2'),
	(7, 'currentCharacterMode', '{"secondHairColor":0,"blushColor":0,"lips":0,"blushModel":-1,"beardColor":0,"sundamageModel":-1,"firstHairColor":58,"noseWidth":0,"cheekboneHeight":0.06,"noseTip":0,"eyebrowsModel":0,"jawHeight":-0.62,"mothersID":25,"makeupModel":-1,"chinPosition":-0.7,"hairModel":35,"noseBridge":0,"jawWidth":0.08,"blemishesModel":-1,"neckWidth":-0.52,"shapeMix":1,"chinWidth":-0.06,"cheekboneWidth":-0.15,"chestModel":-1,"chinShape":0,"eyesColor":26,"noseShift":0,"eyebrowsWidth":0.12,"lipstickColor":0,"eyebrowsHeight":0,"beardModel":-1,"complexionModel":-1,"chestColor":0,"noseHeight":-0.52,"fathersID":0,"noseLength":-0.33,"skinColor":10,"ageingModel":-1,"chinLength":0.95,"cheeksWidth":0,"eyebrowsColor":0,"lipstickModel":-1,"frecklesModel":-1}'),
	(7, 'vRP:colete', '100'),
	(7, 'vRP:datatable', '{"weapons":{"WEAPON_PUMPSHOTGUN_MK2":{"ammo":20},"WEAPON_KNIFE":{"ammo":0},"WEAPON_COMBATPISTOL":{"ammo":134},"WEAPON_NIGHTSTICK":{"ammo":0},"WEAPON_COMBATPDW":{"ammo":0},"WEAPON_SMG":{"ammo":29},"WEAPON_CARBINERIFLE":{"ammo":0},"WEAPON_FLASHLIGHT":{"ammo":0},"WEAPON_STUNGUN":{"ammo":-1},"WEAPON_FIREEXTINGUISHER":{"ammo":2000}},"inventory":{"dinheirosujo":{"amount":1764}},"colete":0,"thirst":88.29999999999984,"health":400,"hunger":38.22500000000004,"customization":{"1":[169,0,1],"2":[35,0,0],"3":[29,0,1],"4":[2,0,1],"5":[34,0,1],"6":[0,0,1],"7":[0,0,2],"8":[7,0,1],"9":[0,0,1],"10":[0,0,2],"11":[2,0,1],"12":[256,0,0],"13":[0,1,0],"14":[0,0,255],"15":[0,1,100],"16":[0,1,6],"17":[0,1,0],"18":[16777472,1,0],"19":[33620225,2,0],"20":[16908545,1,8],"p5":[-1,0],"p6":[8,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"modelhash":1885233650,"p8":[-1,0],"p7":[7,0],"p9":[-1,0],"p0":[-1,0],"0":[0,0,0],"p10":[-1,0]},"groups":{"Concessionaria":true,"Dono":true,"PaisanaSargento":true},"position":{"z":28.70953369140625,"y":-999.2069091796875,"x":852.44921875}}'),
	(7, 'vRP:spawnController', '2'),
	(8, 'currentCharacterMode', '{"secondHairColor":0,"blushColor":0,"lips":0,"blushModel":-1,"fathersID":0,"sundamageModel":-1,"firstHairColor":0,"noseWidth":0,"cheekboneHeight":0,"noseTip":0,"eyebrowsModel":0,"jawHeight":0,"mothersID":21,"makeupModel":-1,"chinPosition":0,"hairModel":4,"noseBridge":0,"jawWidth":0,"chinLength":0,"cheekboneWidth":0,"ageingModel":-1,"chinWidth":0,"lipstickColor":0,"chestModel":-1,"chinShape":0,"eyesColor":0,"eyebrowsHeight":0,"eyebrowsWidth":0,"blemishesModel":-1,"noseShift":0,"beardModel":-1,"complexionModel":-1,"chestColor":0,"neckWidth":0,"shapeMix":0.5,"noseLength":0,"skinColor":6,"beardColor":0,"lipstickModel":-1,"noseHeight":0,"eyebrowsColor":0,"cheeksWidth":0,"frecklesModel":-1}'),
	(8, 'vRP:datatable', '{"colete":0,"thirst":4.58333333333333,"customization":{"1":[0,0,2],"2":[4,0,0],"3":[0,0,2],"4":[5,0,2],"5":[84,0,2],"6":[42,0,2],"7":[0,0,2],"8":[15,0,2],"9":[0,0,2],"10":[0,0,2],"11":[22,0,2],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,2,100],"16":[0,2,1],"17":[0,2,0],"18":[33554944,2,0],"19":[33686018,2,0],"20":[33686018,2,15],"0":[0,0,0],"p0":[-1,0],"p1":[15,0],"p10":[-1,0],"p2":[-1,0],"p5":[-1,0],"p4":[-1,0],"p8":[-1,0],"p9":[-1,0],"p6":[-1,0],"p7":[-1,0],"p3":[-1,0],"modelhash":1885233650},"groups":{"Dono":true,"Concessionaria":true,"Admin":true},"inventory":[],"position":{"z":39.00962448120117,"y":-137.43502807617188,"x":-337.4727783203125},"weapons":[],"health":400,"hunger":2.54166666666666}'),
	(8, 'vRP:spawnController', '2'),
	(9, 'currentCharacterMode', '{"cheekboneWidth":0,"shapeMix":0.5,"lipstickModel":-1,"lips":0,"eyebrowsColor":0,"fathersID":0,"cheeksWidth":0,"noseLength":0,"hairModel":0,"frecklesModel":-1,"chinShape":0,"beardModel":-1,"chinWidth":0,"neckWidth":0,"chinLength":0,"noseHeight":0,"jawWidth":0,"beardColor":0,"noseShift":0,"chestColor":0,"blemishesModel":-1,"chinPosition":0,"noseBridge":0,"eyesColor":0,"noseTip":0,"eyebrowsModel":0,"firstHairColor":0,"skinColor":6,"mothersID":21,"noseWidth":0,"chestModel":-1,"lipstickColor":0,"makeupModel":-1,"eyebrowsWidth":0,"cheekboneHeight":0,"blushModel":-1,"complexionModel":-1,"blushColor":0,"ageingModel":-1,"eyebrowsHeight":0,"sundamageModel":-1,"secondHairColor":0,"jawHeight":0}'),
	(9, 'vRP:colete', '100'),
	(9, 'vRP:datatable', '{"weapons":{"WEAPON_CARBINERIFLE":{"ammo":184},"WEAPON_COMBATPISTOL":{"ammo":187}},"inventory":{"celular":{"amount":1}},"colete":0,"thirst":100,"health":393,"hunger":35.17499999999995,"cloakroom_idle":{"1":[0,0,2],"2":[0,0,0],"3":[0,0,2],"4":[4,0,1],"5":[84,0,2],"6":[42,0,2],"7":[0,0,2],"8":[15,0,2],"9":[0,0,2],"10":[0,0,2],"11":[1,0,1],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,2,100],"16":[0,1,1],"17":[0,2,0],"18":[33554944,2,0],"19":[33686017,2,0],"20":[16908802,2,15],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[15,0],"p10":[-1,0],"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"p5":[-1,0],"modelhash":1885233650,"p0":[-1,0]},"gaptitudes":{"physical":{"strength":20}},"groups":{"Admin":true,"Mecanico":true,"Concessionaria":true,"Dono":true},"position":{"z":82.85932922363281,"y":295.7848815917969,"x":-541.6862182617188},"customization":{"1":[0,0,1],"2":[0,0,0],"3":[6,0,1],"4":[4,0,1],"5":[0,0,1],"6":[12,3,1],"7":[0,0,1],"8":[15,0,2],"9":[0,0,1],"10":[-1,0,2],"11":[92,0,1],"12":[0,0,0],"13":[0,1,0],"14":[0,0,255],"15":[0,1,100],"16":[196608,1,0],"17":[0,1,0],"18":[16777472,1,0],"19":[16843009,1,0],"20":[16908546,2,11],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[26,0],"p10":[-1,0],"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"p5":[-1,0],"modelhash":1885233650,"p0":[11,0]}}'),
	(9, 'vRP:spawnController', '2'),
	(12, 'currentCharacterMode', '{"noseBridge":0,"chinShape":0,"chinWidth":0,"sundamageModel":-1,"eyebrowsHeight":0,"beardModel":18,"hairModel":1,"jawHeight":0,"chinLength":-0.5,"cheekboneWidth":0,"chinPosition":-0.71,"makeupModel":-1,"noseHeight":0,"skinColor":2,"blushModel":-1,"ageingModel":-1,"chestColor":0,"eyesColor":4,"lips":0,"lipstickModel":-1,"eyebrowsColor":0,"firstHairColor":0,"noseTip":0,"noseLength":0,"neckWidth":0,"blushColor":0,"frecklesModel":-1,"complexionModel":-1,"cheekboneHeight":0,"shapeMix":0.58,"noseShift":0,"chestModel":-1,"noseWidth":-0.36,"eyebrowsWidth":0,"beardColor":0,"fathersID":2,"eyebrowsModel":0,"blemishesModel":-1,"jawWidth":0,"secondHairColor":0,"lipstickColor":0,"cheeksWidth":0,"mothersID":21}'),
	(12, 'vRP:datatable', '{"weapons":{"WEAPON_VINTAGEPISTOL":{"ammo":195},"WEAPON_BAT":{"ammo":0},"WEAPON_REVOLVER":{"ammo":0}},"inventory":{"celular":{"amount":4}},"colete":0,"thirst":92.39999999999984,"health":379,"position":{"z":83.02037048339844,"y":292.65667724609377,"x":-544.3120727539063},"gaptitudes":{"physical":{"strength":20}},"groups":{"Admin":true},"hunger":30.79999999999991,"customization":{"1":[4,0,1],"2":[1,0,0],"3":[12,0,1],"4":[4,1,1],"5":[-1,0,2],"6":[27,0,1],"7":[112,3,1],"8":[122,0,1],"9":[-1,0,2],"10":[-1,0,2],"11":[348,0,1],"12":[0,0,0],"13":[0,1,0],"14":[0,0,255],"15":[0,1,228],"16":[50331649,1,1],"17":[0,2,0],"18":[16777472,1,0],"19":[16843265,1,0],"20":[16908801,1,8],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[8,0],"modelhash":1885233650,"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"p10":[-1,0],"p5":[-1,0],"p0":[13,1]}}'),
	(12, 'vRP:spawnController', '2'),
	(13, 'currentCharacterMode', '{"noseBridge":0,"chinShape":0,"chinWidth":0,"sundamageModel":-1,"eyebrowsHeight":0,"beardModel":-1,"gender":1,"hairModel":4,"jawHeight":0,"chinLength":0,"cheekboneWidth":0,"chinPosition":0,"makeupModel":-1,"noseHeight":0,"skinColor":12,"blushModel":-1,"ageingModel":-1,"chestColor":0,"eyesColor":0,"shapeMix":0.99,"eyebrowsColor":0,"fathersID":0,"noseTip":0,"noseLength":0,"neckWidth":0,"blushColor":0,"frecklesModel":-1,"complexionModel":-1,"lips":0,"eyebrowsWidth":0,"noseShift":0,"chestModel":-1,"noseWidth":0,"eyebrowsModel":0,"beardColor":0,"jawWidth":0,"secondHairColor":0,"blemishesModel":-1,"firstHairColor":0,"lipstickModel":-1,"cheekboneHeight":0,"cheeksWidth":0,"lipstickColor":0}'),
	(13, 'vRP:datatable', '{"weapons":{"WEAPON_BAT":{"ammo":0},"WEAPON_KNIFE":{"ammo":0},"WEAPON_STUNGUN":{"ammo":-1},"WEAPON_SMG":{"ammo":98}},"inventory":[],"colete":0,"thirst":90.59999999999985,"health":365,"position":{"z":82.8724136352539,"y":295.4781494140625,"x":-540.96826171875},"customization":{"1":[-1,0,2],"2":[4,0,0],"3":[15,0,2],"4":[8,0,1],"5":[-1,0,2],"6":[0,0,1],"7":[-1,0,2],"8":[5,0,1],"9":[-1,0,2],"10":[-1,0,2],"11":[2,0,1],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,2,100],"16":[0,1,255],"17":[0,2,255],"18":[33554944,1,255],"19":[33620481,2,255],"20":[16908801,1,255],"0":[0,0,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"modelhash":-1667301416,"p8":[-1,0],"p7":[-1,0],"p9":[-1,0],"p0":[-1,0],"p10":[-1,0],"p5":[-1,0]},"gaptitudes":{"physical":{"strength":1320}},"hunger":30.19999999999992,"groups":[]}'),
	(13, 'vRP:spawnController', '2'),
	(15, 'currentCharacterMode', '{"noseBridge":0,"chinShape":0,"chinWidth":0,"sundamageModel":-1,"cheekboneHeight":0,"beardModel":-1,"hairModel":21,"jawHeight":0,"chinLength":0,"cheekboneWidth":0,"chinPosition":0,"makeupModel":-1,"noseHeight":0,"skinColor":6,"blushModel":-1,"ageingModel":-1,"chestColor":0,"eyesColor":0,"lips":0,"lipstickModel":-1,"eyebrowsColor":0,"fathersID":0,"noseTip":0,"noseLength":0,"neckWidth":0,"blushColor":0,"frecklesModel":-1,"complexionModel":-1,"jawWidth":0,"eyebrowsWidth":0,"noseShift":0,"chestModel":-1,"noseWidth":0,"eyebrowsModel":0,"beardColor":0,"firstHairColor":0,"eyebrowsHeight":0,"blemishesModel":-1,"lipstickColor":0,"shapeMix":0.5,"secondHairColor":0,"cheeksWidth":0,"mothersID":22}'),
	(15, 'vRP:datatable', '{"weapons":{"WEAPON_COMBATPISTOL":{"ammo":0},"WEAPON_COMBATPDW":{"ammo":188},"WEAPON_PISTOL_MK2":{"ammo":193},"WEAPON_NIGHTSTICK":{"ammo":0},"WEAPON_FLASHLIGHT":{"ammo":0},"WEAPON_CARBINERIFLE":{"ammo":105}},"inventory":{"roupas":{"amount":1},"celular":{"amount":1}},"colete":0,"thirst":66.00000000000009,"health":313,"position":{"z":34.1625862121582,"y":5485.86474609375,"x":-794.6170043945313},"cloakroom_idle":{"p10":[-1,0],"19":[33686018,2,255],"5":[-1,0,2],"17":[100663296,2,255],"3":[6,0,1],"2":[21,0,0],"1":[0,0,2],"0":[0,0,0],"p5":[-1,0],"15":[0,1,100],"11":[255,6,2],"13":[0,2,0],"9":[-1,0,2],"8":[15,0,2],"7":[-1,0,2],"p8":[-1,0],"18":[16777728,2,255],"20":[33686018,2,255],"10":[-1,0,2],"14":[0,0,255],"12":[0,0,0],"p2":[-1,0],"modelhash":1885233650,"p0":[-1,0],"p9":[-1,0],"p7":[-1,0],"p1":[-1,0],"p3":[-1,0],"6":[48,0,2],"4":[26,0,2],"p4":[-1,0],"16":[0,2,255],"p6":[-1,0]},"customization":{"1":[0,0,2],"2":[21,0,0],"3":[96,0,1],"4":[121,0,1],"5":[-1,0,2],"6":[25,0,1],"7":[0,0,2],"8":[25,0,1],"9":[19,0,1],"10":[-1,0,2],"11":[302,0,1],"12":[0,0,0],"13":[0,2,0],"14":[0,0,255],"15":[0,1,103],"16":[0,1,7],"17":[0,2,0],"18":[16777728,1,0],"19":[33620481,2,0],"20":[16908545,1,3],"p5":[-1,0],"p6":[-1,0],"p3":[-1,0],"p4":[-1,0],"p2":[-1,0],"p1":[-1,0],"p10":[-1,0],"p8":[-1,0],"p7":[3,0],"p9":[-1,0],"modelhash":1885233650,"0":[0,0,0],"p0":[-1,0]},"groups":{"Admin":true,"PaisanaCoronel":true},"hunger":21.99999999999995,"gaptitudes":{"physical":{"strength":20}}}'),
	(15, 'vRP:spawnController', '2');
/*!40000 ALTER TABLE `vrp_user_data` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_homes
CREATE TABLE IF NOT EXISTS `vrp_user_homes` (
  `user_id` int(11) NOT NULL,
  `home` varchar(255) NOT NULL,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`home`),
  CONSTRAINT `fk_user_homes_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_homes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_homes` DISABLE KEYS */;
/*!40000 ALTER TABLE `vrp_user_homes` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_identities
CREATE TABLE IF NOT EXISTS `vrp_user_identities` (
  `user_id` int(11) NOT NULL,
  `registration` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `registration` (`registration`),
  KEY `phone` (`phone`),
  CONSTRAINT `fk_user_identities_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_identities: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_identities` DISABLE KEYS */;
INSERT INTO `vrp_user_identities` (`user_id`, `registration`, `phone`, `firstname`, `name`, `age`) VALUES
	(1, '44YLD722', '219-012', 'Rodox', 'Dr', 35),
	(2, '06JLO193', '015-546', 'Vini', 'ZauM', 29),
	(3, '26HAI515', '578-251', 'marmo', 'ramon', 24),
	(5, '81DIB689', '089-758', 'pow', 'kebrada', 22),
	(7, '02TKA375', '273-552', 'DELAS', 'NAT', 21),
	(8, '78RZP035', '306-062', 'deve', 'deve', 22),
	(9, '86ZPB353', '060-627', 'Britto', 'Dud', 25),
	(12, '85UVY004', '045-154', 'Pisa', 'Chris', 28),
	(13, '02CXK670', '055-160', 'Nanny', 'Barbie', 23),
	(15, '97SRY151', '971-493', 'cezar', 'julio', 20);
/*!40000 ALTER TABLE `vrp_user_identities` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_ids
CREATE TABLE IF NOT EXISTS `vrp_user_ids` (
  `identifier` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`identifier`),
  KEY `fk_user_ids_users` (`user_id`),
  CONSTRAINT `fk_user_ids_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_ids: ~42 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_ids` DISABLE KEYS */;
INSERT INTO `vrp_user_ids` (`identifier`, `user_id`) VALUES
	('license2:8443a82d06bb43c343eb5a0dd8bed331493b74e6', 1),
	('license:efb4e1e82e9bb767699ddced458d24354281fc1b', 1),
	('fivem:3385199', 2),
	('license2:47a82b52ba3c7eeaa9d781f81a5c15c3a6c5ed60', 2),
	('license:47a82b52ba3c7eeaa9d781f81a5c15c3a6c5ed60', 2),
	('live:1899945891599025', 2),
	('steam:1100001050418fc', 2),
	('xbl:2535471206259655', 2),
	('discord:881685055989227570', 3),
	('fivem:3376421', 3),
	('license2:83b5db1bcda0e63f3e6417fc033943dfbebbbc88', 3),
	('license:1f922f65a47804aa2dddf1e89b3d77750ddfd48e', 3),
	('steam:110000106a7e601', 3),
	('discord:847697608294137917', 4),
	('license2:2e12c05818178c5feacc9f058790804d55d74da1', 4),
	('license:2e12c05818178c5feacc9f058790804d55d74da1', 4),
	('live:1829581103325740', 4),
	('steam:110000148589aa3', 4),
	('xbl:2535447335001771', 4),
	('discord:638784394617946122', 5),
	('license2:1d9ba90f56c9e26599d005f1ec42d58f8a1104b0', 5),
	('license:1d9ba90f56c9e26599d005f1ec42d58f8a1104b0', 5),
	('discord:695075562804215808', 6),
	('license2:5bf494cffbaeda27c104621c3a1cce4a3c00cd4b', 6),
	('license:5bf494cffbaeda27c104621c3a1cce4a3c00cd4b', 6),
	('live:985154863675740', 6),
	('steam:11000013f89f114', 6),
	('discord:752972526413676575', 7),
	('license2:13e3e38b5aaf8a18e25a8ea6163b3a02dbb18a12', 7),
	('license:13e3e38b5aaf8a18e25a8ea6163b3a02dbb18a12', 7),
	('live:914798779925388', 7),
	('steam:1100001486393bb', 7),
	('xbl:2535459728592915', 7),
	('discord:294621761041858560', 8),
	('fivem:877213', 8),
	('license2:08fb631dac569efee96fcf9b1923f63aabca531a', 8),
	('license:08fb631dac569efee96fcf9b1923f63aabca531a', 8),
	('steam:110000106c33a48', 8),
	('discord:553284504748556306', 9),
	('license2:4240022f281131e89e22af09c03ce246ae908990', 9),
	('license:3423825d2de1239858ec2255fe98e67d72861cee', 9),
	('steam:110000115c2c041', 9),
	('discord:822654688150421554', 10),
	('license2:0a70abef94904b1d8eabd4db270577a36b7609e9', 10),
	('license:0a70abef94904b1d8eabd4db270577a36b7609e9', 10),
	('live:1055519030961110', 10),
	('steam:11000014918472e', 10),
	('xbl:2535458662607049', 10),
	('discord:439993605365432321', 11),
	('fivem:2172961', 11),
	('license2:c2b528a372d27a9915c00943459adbde3185ddef', 11),
	('license:c2b528a372d27a9915c00943459adbde3185ddef', 11),
	('steam:1100001345b0551', 11),
	('discord:755646210039349300', 12),
	('fivem:2715383', 12),
	('license2:8a2441986def00f4e6ef03f83588cef44ac80812', 12),
	('license:8a2441986def00f4e6ef03f83588cef44ac80812', 12),
	('steam:1100001409cd51e', 12),
	('license2:82c0e0c3063ab1edea285af738c841da100b5e4e', 13),
	('license:82c0e0c3063ab1edea285af738c841da100b5e4e', 13),
	('live:1899945844959939', 13),
	('xbl:2535411662347336', 13),
	('discord:262785481803169792', 14),
	('license2:f886cb3fe413c3e91cc97312addef29e40f88466', 14),
	('license:f886cb3fe413c3e91cc97312addef29e40f88466', 14),
	('live:1759222091418837', 14),
	('steam:1100001372d19f2', 14),
	('xbl:2535447960458528', 14),
	('discord:530204694035955712', 15),
	('license2:a0b1d3621a4b56e0bf22a5fad257b4a7ee4b7f18', 15),
	('license:0a9ff20d49b4ffe3a2f10b8cf166c9864f56d011', 15),
	('live:914802257210894', 15),
	('xbl:2535455207762649', 15),
	('discord:452965515229659136', 16),
	('license2:a275de2726301f0047fd5cad1c2043b102e68536', 16),
	('license:a275de2726301f0047fd5cad1c2043b102e68536', 16),
	('live:985154689794076', 16);
/*!40000 ALTER TABLE `vrp_user_ids` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_moneys
CREATE TABLE IF NOT EXISTS `vrp_user_moneys` (
  `user_id` int(11) NOT NULL,
  `wallet` int(11) DEFAULT NULL,
  `bank` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_moneys_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_moneys: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_moneys` DISABLE KEYS */;
INSERT INTO `vrp_user_moneys` (`user_id`, `wallet`, `bank`) VALUES
	(1, 24903041, 104500),
	(2, 304480655, 204200),
	(3, 1095125200, 77000),
	(5, 0, 25500),
	(7, 4025, 23000),
	(8, 5000, 15000),
	(9, 0, 30800),
	(12, 0, 46100),
	(13, 4625, 55000),
	(15, 5000, 103000);
/*!40000 ALTER TABLE `vrp_user_moneys` ENABLE KEYS */;

-- Copiando estrutura para tabela vrpex.vrp_user_vehicles
CREATE TABLE IF NOT EXISTS `vrp_user_vehicles` (
  `user_id` int(11) NOT NULL,
  `vehicle` varchar(100) NOT NULL,
  `detido` int(1) NOT NULL DEFAULT 0,
  `time` varchar(24) NOT NULL DEFAULT '0',
  `engine` int(4) NOT NULL DEFAULT 1000,
  `body` int(4) NOT NULL DEFAULT 1000,
  `fuel` int(3) NOT NULL DEFAULT 100,
  `ipva` int(11) NOT NULL,
  `alugado` tinyint(4) NOT NULL DEFAULT 0,
  `data_alugado` text DEFAULT NULL,
  `estado` text DEFAULT '[]',
  PRIMARY KEY (`user_id`,`vehicle`),
  KEY `ipva` (`ipva`),
  CONSTRAINT `fk_user_vehicles_users` FOREIGN KEY (`user_id`) REFERENCES `vrp_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vrpex.vrp_user_vehicles: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `vrp_user_vehicles` DISABLE KEYS */;
INSERT INTO `vrp_user_vehicles` (`user_id`, `vehicle`, `detido`, `time`, `engine`, `body`, `fuel`, `ipva`, `alugado`, `data_alugado`, `estado`) VALUES
	(2, 'aperta', 0, '0', 1000, 1000, 100, 1631727521, 0, NULL, '[]'),
	(3, 'aperta', 0, '0', 1000, 908, 65, 1631673066, 0, NULL, '[]'),
	(3, 'dodgechargersrt', 0, '0', 1000, 1000, 65, 1631899102, 1, '17/09/2021', '[]'),
	(3, 'flashgt', 0, '0', 1000, 1000, 100, 1631899285, 1, '17/09/2021', '[]'),
	(3, 'ftoro', 0, '0', 936, 968, 65, 1631745192, 0, NULL, '[]'),
	(3, 'jetta', 0, '0', 1000, 1000, 65, 1631745112, 0, NULL, '[]'),
	(3, 'palio97', 0, '0', 989, 989, 65, 1631760956, 0, NULL, '[]'),
	(12, 'asea', 0, '0', 1000, 1000, 100, 1631913686, 1, '17/09/2021', '[]'),
	(12, 'mule4', 0, '0', 1000, 1000, 100, 1631914760, 1, '17/09/2021', '[]');
/*!40000 ALTER TABLE `vrp_user_vehicles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
